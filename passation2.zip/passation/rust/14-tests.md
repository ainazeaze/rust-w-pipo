> https://doc.rust-lang.org/stable/book/ch11-00-testing.html  
> https://doc.rust-lang.org/rust-by-example/testing.html  

# Tests Unitaires

> https://doc.rust-lang.org/rust-by-example/testing/unit_testing.html  

```rust
#[derive(Debug, PartialEq)]
enum Direction {
    North,
    South,
    West,
    East,
}

impl Direction {
    pub fn clockwise(&self) -> Self {
        match self {
            Self::North => Self::East,
            Self::South => Self::West,
            Self::West => Self::North,
            Self::East => Self::South,
        }
    }

    pub fn counter_clockwise(&self) -> Self {
        match self {
            Self::North => Self::West,
            Self::South => Self::East,
            Self::West => Self::South,
            Self::East => Self::North,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clockwise() {
        assert_eq!(Direction::North.clockwise(), Direction::East);
        assert_eq!(Direction::South.clockwise(), Direction::West);
    }

    #[test]
    fn counter_clockwise() {
        assert_eq!(Direction::North.counter_clockwise(), Direction::West);
        assert_eq!(Direction::South.counter_clockwise(), Direction::East);
    }
}
```

# Tests d'integration

> https://doc.rust-lang.org/rust-by-example/testing/integration_testing.html  

```rust
// tests/direction.rs
use my_crate::direction::Direction;

#[test]
fn clockwise() {
    assert_eq!(Direction::North.clockwise(), Direction::East);
    assert_eq!(Direction::South.clockwise(), Direction::West);
}

#[test]
fn counter_clockwise() {
    assert_eq!(Direction::North.counter_clockwise(), Direction::West);
    assert_eq!(Direction::South.counter_clockwise(), Direction::East);
}
```

# Documentation

La notation `///` permet de faire des commentaires sur des elements (fonction, struct, enum, ...) en mode documentation. Le texte est interprété comme du markdown, on peut donc structurer la documentation. Il est également possible de lancer les tests sur les exemples de code dans les documentation.

La notation `//!` permet de faire des commentaires de modules et a les mêmes propriété que les commentaires documentation normales.

```rust
//! Hello this is an adder package

/// Adding two integers *left* and **right**
///
/// # Example
///
/// ```
/// let res = adder::add(1, 3);
///
/// assert_eq!(res, 4);
/// ```
pub fn add(left: u64, right: u64) -> u64 {
    left + right
}

/// Adding one to an integer. Uses [add].
///
/// # Example
///
/// ```
/// let res = adder::add_one(5);
///
/// assert_eq!(res, 6);
/// ```
pub fn add_one(value: u64) -> u64 {
    add(value, 1)
}
```