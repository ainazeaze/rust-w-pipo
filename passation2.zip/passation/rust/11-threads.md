> https://doc.rust-lang.org/stable/book/ch16-00-concurrency.html  
> https://doc.rust-lang.org/stable/std/thread/index.html  

# Spawn

> https://doc.rust-lang.org/stable/std/thread/fn.spawn.html  
> https://doc.rust-lang.org/stable/std/thread/fn.scope.html  

# Send

> https://doc.rust-lang.org/std/marker/trait.Send.html  

Un type peut être envoyé dans un thread.
Par exemple, `Rc` n'est pas `Sync` car il n'est pas "thread-safe"
Trait implémenté par défaut si les elements qui le compose l'implementent, on peut enlever l'implementation mais c'est unsafe.

# Sync

> https://doc.rust-lang.org/std/marker/trait.Sync.html  

Un type dont la reference peut être partagée dans un thread.
`Cell<T>` peut être `Send` si `T: Send` mais il ne peut jamais être `Sync`
Trait implémenté par défaut si les elements qui le compose l'implementent, on peut enlever l'implementation mais c'est unsafe.

# Arc

> https://doc.rust-lang.org/stable/std/sync/struct.Arc.html  
> https://doc.rust-lang.org/rust-by-example/std/arc.html#arc  

```rust
use std::{sync::Arc, thread};

struct Client {
    name: String,
    age: i32,
}

fn main() {
    let client = Arc::new(Client {
        name: String::from("Alice"),
        age: 42,
    });

    let c = client.clone();
    let handle = thread::spawn(move || {
        println!("(thread) {} is {} years old", c.name, c.age);
    });

    println!("{} is {} years old", client.name, client.age);
    handle.join().unwrap();
}
```

# Mutabilité intérieure Mutex et RwLock

> https://doc.rust-lang.org/stable/book/ch16-03-shared-state.html  
> https://docs.rs/parking_lot/latest/parking_lot/type.Mutex.html  
> https://doc.rust-lang.org/stable/std/sync/struct.RwLock.html  
> https://docs.rs/parking_lot/latest/parking_lot/type.RwLock.html  


```rust
use std::{
    sync::{Arc, Mutex},
    thread,
};

struct Client {
    name: String,
    age: Mutex<i32>,
}

fn main() {
    let client = Arc::new(Client {
        name: String::from("Alice"),
        age: Mutex::new(42),
    });

    let c = client.clone();
    let handle = thread::spawn(move || {
        let mut age = c.age.lock().unwrap();
        println!("(thread) {} is {} years old", c.name, age);
        *age += 1;
    });

    handle.join().unwrap();
    println!(
        "{} is {} years old",
        client.name,
        client.age.lock().unwrap()
    );
}
```
# Channel

> https://doc.rust-lang.org/stable/book/ch16-02-message-passing.html  

```rust
use std::{sync::mpsc::channel, thread, time::Duration};

fn main() {
    let (s, r) = channel::<String>();

    let ss = s.clone();
    thread::spawn(move || {
        loop {
            ss.send(String::from("Hello from first thread")).unwrap();
            thread::sleep(Duration::from_secs(2));
        }
    });

    let ss = s.clone();
    thread::spawn(move || {
        loop {
            ss.send(String::from("Hello from second thread")).unwrap();
            thread::sleep(Duration::from_secs(1));
        }
    });

    for msg in r {
        println!("{msg}");
    }
}
```

# Résumé des differents types de ownership

> https://old.reddit.com/r/rust/comments/mgh9n9/ownership_concept_diagram/  