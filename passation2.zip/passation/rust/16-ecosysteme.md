> https://blessed.rs/crates  
> https://lib.rs/  
# Dependances

`cargo add`

# Serde

> https://serde.rs/  

```
{"type":"A","content":{"fst":3}}
{"type":"B","content":{"myFirst":3.5,"mySecond":5.7}}
```

```rust
enum Thing {
    A { my_first: i32 },
    B { my_first: f32, my_second: f32 },
}

impl Serialize for Thing {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let mut st = serializer.serialize_struct("Thing", 2)?;
        match self {
            Self::A { my_first } => {
                st.serialize_field("type", "A")?;

                struct AContent(i32);

                impl Serialize for AContent {
                    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
                    where
                        S: Serializer,
                    {
                        let mut st = serializer.serialize_struct("AContent", 1)?;
                        st.serialize_field("fst", &self.0)?;
                        st.end()
                    }
                }

                st.serialize_field("content", &AContent(*my_first))?;
            }
            Self::B {
                my_first,
                my_second,
            } => {
                st.serialize_field("type", "B")?;

                struct BContent(f32, f32);

                impl Serialize for BContent {
                    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
                    where
                        S: Serializer,
                    {
                        let mut st = serializer.serialize_struct("BContent", 1)?;
                        st.serialize_field("myFirst", &self.0)?;
                        st.serialize_field("mySecond", &self.1)?;
                        st.end()
                    }
                }

                st.serialize_field("content", &BContent(*my_first, *my_second))?;
            }
        }

        st.end()
    }
}
```

```rust
#[derive(Serialize)]
#[serde(tag = "type", content = "content", rename_all_fields = "camelCase")]
enum Thing {
    A {
        #[serde(rename = "fst")]
        my_first: i32,
    },
    B {
        my_first: f32,
        my_second: f32,
    },
}
```

```rust
fn main() {
    let ta = Thing::A { my_first: 3 };
    let tb = Thing::B {
        my_first: 3.5,
        my_second: 5.7,
    };

    println!("{}", serde_json::to_string(&ta).unwrap());
    println!("{}", serde_json::to_string(&tb).unwrap());
    println!("{}", toml::to_string(&ta).unwrap());
    println!("{}", toml::to_string(&tb).unwrap());
}

```

# Axum

Serveur Web maintenu par l'équipe Tokio.

Exemple :
```rust
use std::{
    collections::HashMap,
    sync::{Arc, RwLock},
};

use axum::{
    extract::{Path, State},
    http::{HeaderMap, HeaderValue, StatusCode, header},
    response::IntoResponse,
    routing::get,
};

async fn root() -> impl IntoResponse {
    let mut headers = HeaderMap::new();
    headers.insert(header::FROM, HeaderValue::from_static("Pipo"));
    headers.insert("Pipo", HeaderValue::from_static("true"));
    (StatusCode::TOO_MANY_REQUESTS, headers, "Hello World!")
}


async fn get_value(Path(id): Path<u32>, State(state): State<Arc<AppState>>) -> String {
    state
        .values
        .read()
        .unwrap()
        .get(&id)
        .copied()
        .unwrap_or_default()
        .to_string()
}

enum SetValueError {
    InvalidValue(String),
}

impl IntoResponse for SetValueError {
    fn into_response(self) -> axum::response::Response {
        match self {
            Self::InvalidValue(value) => format!("Invalid value: {value}").into_response(),
        }
    }
}

async fn set_value(
    Path(id): Path<u32>,
    State(state): State<Arc<AppState>>,
    body: String,
) -> Result<(), SetValueError> {
    let value = body
        .trim()
        .parse()
        .map_err(|_| SetValueError::InvalidValue(body))?;

    state.values.write().unwrap().insert(id, value);
    Ok(())
}

#[derive(Default)]
struct AppState {
    values: RwLock<HashMap<u32, u32>>,
}

#[tokio::main]
async fn main() {
    let app = axum::Router::new()
        .route("/", get(root))
        .route("/values/{id}", get(get_value).post(set_value))
        .with_state(Arc::new(AppState::default()));

    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
```

Exemple avec serde :
```rust
use axum::{Json, routing::get};
use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Serialize)]
struct User {
    name: String,
    age: i32,
    location: Option<String>,
}

async fn get_user() -> Json<User> {
    Json(User {
        name: String::from("John Doe"),
        age: 42,
        location: None,
    })
}

async fn post_user(Json(user): Json<User>) {
    println!("Got user {user:?}");
}

#[tokio::main]
async fn main() {
    let app = axum::Router::new().route("/user", get(get_user).post(post_user));

    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
```
# Thiserror

Exemple sans thiserror :
```rust
mod api {
    use std::{error::Error, fmt::Display, fs::File, io};

    #[derive(Debug)]
    pub enum ApiError {
        InvalidThing,
        NotFound(u32),
        Io(io::Error),
    }

    impl Error for ApiError {}
    impl Display for ApiError {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            match self {
                Self::InvalidThing => write!(f, "Received invalid thing"),
                Self::NotFound(id) => write!(f, "Ressource {id} not found"),
                Self::Io(err) => err.fmt(f),
            }
        }
    }

    impl From<io::Error> for ApiError {
        fn from(value: io::Error) -> Self {
            Self::Io(value)
        }
    }

    pub fn foo() -> Result<(), ApiError> {
        Err(ApiError::InvalidThing)
    }

    pub fn bar() -> Result<(), ApiError> {
        Err(ApiError::NotFound(67))
    }

    pub fn baz() -> Result<File, ApiError> {
        Ok(File::open("qwkfsdfj")?)
    }
}

use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    match api::bar() {
        Ok(_) => (),
        Err(err) => println!("{err}"),
    }

    match api::baz() {
        Ok(_) => (),
        Err(err) => println!("{err}"),
    }

    api::foo()?;

    Ok(())
}
```

Exemple avec thiserror :
```rust
mod api {
    use std::{fs::File, io};

    use thiserror::Error;

    pub type ApiResult<T> = Result<T, ApiError>;

    #[derive(Debug, Error)]
    pub enum ApiError {
        #[error("Received invalid thing")]
        InvalidThing,

        #[error("Resource {0} not found")]
        NotFound(u32),

        #[error(transparent)]
        Io(#[from] io::Error),
    }

    pub fn foo() -> ApiResult<()> {
        Err(ApiError::InvalidThing)
    }

    pub fn bar() -> ApiResult<()> {
        Err(ApiError::NotFound(67))
    }

    pub fn baz() -> ApiResult<File> {
        Ok(File::open("qwkfsdfj")?)
    }
}

use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    match api::bar() {
        Ok(_) => (),
        Err(err) => println!("{err}"),
    }

    match api::baz() {
        Ok(_) => (),
        Err(err) => println!("{err}"),
    }

    api::foo()?;

    Ok(())
}
```

# Anyhow

Exemple sans anyhow :
```rust
use std::error::Error;

fn do_something(a: &str, b: &str) -> Result<(), Box<dyn Error>> {
    let a: u32 = a.parse()?;
    let b: u32 = b.parse()?;
    Ok(api::bar(a + b)?)
}

fn main() -> Result<(), Box<dyn Error>> {
    do_something("67", "2")?;

    Ok(())
}
```

Exemple avec anyhow :
```rust
fn do_something(a: &str, b: &str) -> anyhow::Result<()> {
    let a: u32 = a.parse().context("parsing a in do_something")?;
    let b: u32 = b.parse().context("parsing b in do_something")?;
    Ok(api::bar(a + b)?)
}

fn main() -> anyhow::Result<()> {
    do_something("67", "2")?;

    Ok(())
}
```

# Tracing

`tracing` permet de définir les logs, `tracing-subscriber` permet de les activer

```rust
mod api {
    use std::{fs::File, io};

    use thiserror::Error;

    pub type ApiResult<T> = Result<T, ApiError>;

    #[derive(Debug, Error)]
    pub enum ApiError {
        #[error("Received invalid thing")]
        InvalidThing,

        #[error("Resource {0} not found")]
        NotFound(u32),

        #[error(transparent)]
        Io(#[from] io::Error),
    }

    pub fn foo() -> ApiResult<()> {
        tracing::info!("Running foo");
        let res = Err(ApiError::InvalidThing);
        tracing::error!("Invalid Thing !!!");
        res
    }

    pub fn bar(id: u32) -> ApiResult<()> {
        tracing::info!("Running foo");
        let res = Err(ApiError::NotFound(id));
        tracing::warn!(id, "Not found");
        res
    }

    pub fn baz(path: &str) -> ApiResult<File> {
        tracing::info!(path, "Opening file");
        Ok(File::open(path)?)
    }
}

fn do_something(a: &str, b: &str) -> anyhow::Result<()> {
    let a: u32 = a.parse()?;
    let b: u32 = b.parse()?;
    Ok(api::bar(a + b)?)
}

fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt::init();

    let _ = api::foo();
    let _ = api::baz("qweqwe");
    let _ = do_something("67", "2");

    Ok(())
}
```

# Autres

Sur https://blessed.rs/ :
- rand
- jiff/time
- regex
- reqwest
- clap
- bitflags
- parking_lot