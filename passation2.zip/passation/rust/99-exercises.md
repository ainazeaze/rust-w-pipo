https://adventofcode.com/2016/day/8

# Stack ou Heap ?

```rust
let a = 5;
let b = "Hello";
let mut c = "Hello";
let d = String::from("Hello");
let e = "Hello".to_string();
let f = [10, 20, 30];
let g = vec![10, 20, 30];
let h = Box::new(5);
```

# Traits

```rust
trait Present {
    fn present(&self) -> String;
}

let first_name = FirstName(String::from("James"));
let last_name = LastName(String::from("Bond"));
let full_name = first_name + last_name;
assert_eq!(first_name.present(), String::from("My first name is James"));
assert_eq!(last_name.present(), String::from("Bond is my last name"));
assert_eq!(full_name.present(), String::from("My name is Bond, James Bond"));
```

# Generics

```rust
// TODO fn sum

let a: i32 = sum(&[0, 1, 2]); // 3
let b: i64 = sum(&[]); // 0
let c: i16 = sum(&[6]); // 6
let d: f64 = sum(&[1.5, 5.5, 1.7]); // 8.7
let e: i32 = sum([7, 3, 5]); // 15  
let f: f32 = sum(vec![4.6, 2.6, 9.7]); // 16.9
```

# Counter Iterator

```rust
// TODO Counter

fn main() {
    let cpt = Counter::new(3, 6);
    for i in cpt {
        println!("{i}");
    }
}

// Output :
// 3
// 4
// 5
// 6
```

https://adventofcode.com/2024/day/2

# Optimisation Enum

```rust
enum Thing {
    A,
}

impl std::fmt::Display for Thing {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "A")
    }
}

fn main() {
    println!("{}", Thing::A);
}
```

# Pair

```rust
// TODO: Pair

fn main() {
    let pair = Pair(3, 4);
    println!("{}", pair.sum()); // 7

    let pair = Pair("Hello", "World");
    println!("{}", pair.join(" ")); // Hello World
    println!("{}", pair.join('-')); // Hello-World
    println!("{}", pair.join(0)); // Hello0World

    let pair: Pair<i32, String> = Pair::default();
    println!("{:?}", pair); // Pair(0, "")
    
    let pair = Pair(6, 7);
    for i in pair {
        println!("{}", i); // 6 then 7
    }
}
```

# Lifetime

```rust
struct StringHandle<'a> {
    s: &'a String,
}

// TODO impl StringHandle

fn main() {
    let a = String::from("foo");
    let b = String::from("bar");

    {
        let mut handle = StringHandle::new(&a);
        println!("{}", handle.get_string());
        handle.set_string(&b);
        println!("{}", handle.get_string());
    }

    println!("{} {}", a, b);
}
```

# Smart Pointer

```rust
fn main() {
    let alice = Client::new("Alice");
    let bob = Client::new("Bob");
    let charlie = Client::new("Charlie");

    let mut room_a = ChatRoom::new();
    room_a.join(alice.clone());
    room_a.join(bob.clone());
    let mut room_b = ChatRoom::new();
    room_b.join(bob.clone());
    room_b.join(charlie.clone());
    let mut room_c = ChatRoom::new();
    room_c.join(alice.clone());
    room_c.join(charlie.clone());

    room_a.send("Hello Room A");
    room_b.send("Hello Room B");
    room_c.send("Hello Room C");

    // print messages for each
}
```
