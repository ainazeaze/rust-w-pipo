> https://doc.rust-lang.org/stable/book/ch15-00-smart-pointers.html#smart-pointers  

# Box

> https://doc.rust-lang.org/stable/book/ch15-01-box.html  
> https://doc.rust-lang.org/stable/std/boxed/struct.Box.html  
> https://doc.rust-lang.org/rust-by-example/std/box.html#box-stack-and-heap  

```rust
#[derive(Debug)]
struct Node<T> {
    value: T,
    next: Option<Box<Node<T>>>,
}

impl<T: std::fmt::Display> Node<T> {
    fn print(&self) {
        println!("{}", self.value);
        if let Some(next) = &self.next {
            next.print();
        }
    }
}

fn main() {
    let head = Node {
        value: 1,
        next: Some(Box::new(Node {
            value: 2,
            next: None,
        })),
    };

    head.print();
}
```

# Rc

> https://doc.rust-lang.org/stable/book/ch15-04-rc.html  

```rust
use std::rc::Rc;

#[derive(Debug)]
struct Node<T> {
    value: T,
    next: Option<Rc<Node<T>>>,
}

impl<T: std::fmt::Display> Node<T> {
    fn print(&self) {
        println!("{}", self.value);
        if let Some(next) = &self.next {
            next.print();
        } else {
            println!();
        }
    }
}

fn main() {
    let head = Rc::new(Node {
        value: 1,
        next: Some(Rc::new(Node {
            value: 2,
            next: None,
        })),
    });

    let a = Node {
        value: 3,
        next: Some(head.clone()),
    };

    let b = Node {
        value: 4,
        next: Some(head),
    };

    a.print();
    b.print();
}
```

# Mutabilité intérieure avec Cell et RefCell

> https://doc.rust-lang.org/stable/book/ch15-05-interior-mutability.html  
> https://doc.rust-lang.org/std/cell/index.html
> https://stackoverflow.com/questions/30275982/when-i-can-use-either-cell-or-refcell-which-should-i-choose  

Cell active la mutabilité intérieure mais on ne peut jamais avoir la reference à l’intérieur. De ce fait, il faut mettre un type qui implémente Copy a l’intérieur :

```rust
use std::{cell::Cell, rc::Rc};

#[derive(Debug)]
struct Node<T: Copy> {
    value: Cell<T>,
    next: Option<Rc<Node<T>>>,
}

impl<T: std::fmt::Display + Copy> Node<T> {
    fn print(&self) {
        print!("{} ", self.value.get());
        if let Some(next) = &self.next {
            next.print();
        } else {
            println!();
        }
    }
}

fn main() {
    let head = Rc::new(Node {
        value: Cell::new(1),
        next: Some(Rc::new(Node {
            value: Cell::new(2),
            next: None,
        })),
    });

    let a = Node {
        value: Cell::new(3),
        next: Some(head.clone()),
    };

    let b = Node {
        value: Cell::new(4),
        next: Some(head.clone()),
    };

    a.print();
    b.print();

    head.value.set(10);

    a.print();
    b.print();
}
```

RefCell est une alternative a Cell qui fonctionne de la même façon mais qui permet de récupérer la reference de la valeur a l’intérieur :

```rust
#[derive(Debug)]
struct Node<T> {
    value: RefCell<T>,
    next: Option<Rc<Node<T>>>,
}

impl<T: std::fmt::Display> Node<T> {
    fn print(&self) {
        print!("{} ", self.value.borrow());
        if let Some(next) = &self.next {
            next.print();
        } else {
            println!();
        }
    }
}

fn main() {
    let head = Rc::new(Node {
        value: RefCell::new(Number(1)),
        next: Some(Rc::new(Node {
            value: RefCell::new(Number(2)),
            next: None,
        })),
    });

    let a = Node {
        value: RefCell::new(Number(3)),
        next: Some(head.clone()),
    };

    let b = Node {
        value: RefCell::new(Number(4)),
        next: Some(head.clone()),
    };

    a.print();
    b.print();

    *head.value.borrow_mut() = Number(10);

    a.print();
    b.print();
}
```

Il n'est pas possible d'avoir une reference immutable quand une reference mutable existe :

```rust
let mut v = head.value.borrow_mut();
*v = Number(10);
println!("{}", head.value.borrow()); // PANIC: RefCell already mutably borrowed
```