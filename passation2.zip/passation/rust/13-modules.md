# Types de projets

- library avec un `lib.rs` a la racine (`cargo new --lib`)
- programme avec un `main.rs` a la racine (`cargo new`)
- les deux

# Fichiers cargo
# Module

```rust
mod foo {
    fn a() {
        b()
    }

    fn b() {}

    mod bar {
        fn c() {
            super::b();
        }
    }
}

mod bar {
    fn a() {}
}
```

# Module fichier


```rust
// lib.rs ou main.rs
mod foo;
mod bar;
```

```rust
// foo.rs
fn a() {
	b()
}

fn b() {}

mod bar {
	fn c() {
		super::b();
	}
}
```

```rust
fn a() {}
```

# Visibilité

> https://doc.rust-lang.org/rust-by-example/mod/visibility.html  

- Aucun mot clé : private
- `pub` : public
- `pub(crate)` : public pour la crate uniquement
- `pub(super)` : public pour le module parent

# Layout

> https://doc.rust-lang.org/cargo/guide/project-layout.html  

# Workspace (monorepo)

> https://doc.rust-lang.org/book/ch14-03-cargo-workspaces.html  