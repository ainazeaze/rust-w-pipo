> https://rust-unofficial.github.io/patterns/  

# NewType

> https://rust-unofficial.github.io/patterns/patterns/behavioural/newtype.html  

Permet de renforcer les types utilisés :
```rust
struct BadName {
	first_name: String,
	last_name: String,
}

impl BadName {
	fn new(first_name: String, last_name: String) -> Self {
		Self { first_name, last_name }
	}
}

#[derive(Debug, Clone)]
struct FirstName(String);

#[derive(Debug, Clone)]
struct LastName(String);

struct GoodName {
	first_name: FirstName,
	last_name: LastName,
}

fn main() {
	let first_name = String::from("John");
	let last_name = String::from("Doe");
	let name1 = Name::new(first_name.clone(), last_name.clone());
	let name2 = Name::new(last_name.clone(), first_name.clone()); // NO ERROR
	
	let first_name = FirstName(String::from("John"));
	let last_name = LastName(String::from("Doe"));
	let name1 = Name::new(first_name.clone(), last_name.clone());
	let name2 = Name::new(last_name.clone(), first_name.clone()); // ERROR
}
```


Permet de contourner la "orphan rule" :
```rust
use std::ops::Add;

// ERROR
impl Add for String {
    type Output = String;

    fn add(self, rhs: Self) -> Self::Output {
        format!("{}{}", self, rhs)
    }
}

#[derive(Debug)]
struct MyString(String);

impl Add for MyString {
    type Output = MyString;

    fn add(self, rhs: Self) -> Self::Output {
        MyString(format!("{}{}", self.0, rhs.0))
    }
}

fn main() {
    let s1 = MyString(String::from("Hello"));
    let s2 = MyString(String::from(" World"));

    let s3 = s1 + s2;
    println!("{s3:?}");
}
```

Ça peut rendre le code moins pratique si on souhaite utiliser le vrai type dans notre nouveau type, mais on peut implementer Deref pour aider :
```rust
use std::ops::Deref;

struct FirstName(String);

impl Deref for FirstName {
    type Target = String;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

fn main() {
    let first_name = FirstName(String::from("John"));
    println!("{}", first_name.to_uppercase());
}
```

Il est d'ailleurs recommandé d'utiliser des enums au lieu de booleans :
```rust
struct Foo;

enum Visiblity {
    Shown,
    Hidden,
}

impl Foo {
    fn bad_visible(&self) -> bool {
        true
    }

    fn good_visible(&self) -> Visibility {
        Visibility::Shown
    }
}
```

# Builder

> https://rust-unofficial.github.io/patterns/patterns/creational/builder.html  

La création se fait par des constructeurs :
```rust
enum Class {
    Warrior,
    Mage,
    Rogue,
}

struct Character {
    name: String,
    age: Option<i32>,
    class: Class,
    health: u32,
    mana: u32,
}

impl Character {
    fn new(name: String, age: Option<i32>, class: Class, health: u32, mana: u32) -> Self {
        Self {
            name,
            age,
            class,
            health,
            mana,
        }
    }
}

fn main() {
    let character = Character::new(String::from("John"), None, Class::Warrior, 100, 200);
}
```

Cet exemple présente plusieurs problèmes :
- Le constructeur est long
- Si on ne souhaite pas mettre d'age on doit quand même mettre `None`
- Pas de possibilité d'avoir des valeurs `health` et `mana` par défaut

```rust
#[derive(Debug, Default)]
enum Class {
    #[default]
    Warrior,
    Mage,
    Rogue,
}

#[derive(Debug)]
struct Character {
    name: String,
    age: Option<i32>,
    class: Class,
    health: u32,
    mana: u32,
}

#[derive(Default)]
struct CharacterBuilder {
    name: Option<String>,
    age: Option<i32>,
    class: Option<Class>,
    health: Option<u32>,
    mana: Option<u32>,
}

#[derive(Debug)]
struct MissingField(&'static str);

impl CharacterBuilder {
    fn new() -> Self {
        Self::default()
    }

    fn name<S: Into<String>>(mut self, name: S) -> Self {
        self.name = Some(name.into());
        self
    }

    fn age(mut self, age: i32) -> Self {
        self.age = Some(age);
        self
    }

    fn class(mut self, class: Class) -> Self {
        self.class = Some(class);
        self
    }

    fn health(mut self, health: u32) -> Self {
        self.health = Some(health);
        self
    }

    fn mana(mut self, mana: u32) -> Self {
        self.mana = Some(mana);
        self
    }

    fn build1(self) -> Character {
        Character {
            name: self.name.unwrap_or(String::from("Unknown")),
            age: self.age,
            class: self.class.unwrap_or_default(),
            health: self.health.unwrap_or(100),
            mana: self.mana.unwrap_or(100),
        }
    }

    fn build2(self) -> Result<Character, MissingField> {
        Ok(Character {
            name: self.name.ok_or(MissingField("Name"))?,
            age: self.age,
            class: self.class.ok_or(MissingField("Class"))?,
            health: self.health.unwrap_or(100),
            mana: self.mana.unwrap_or(100),
        })
    }
}

fn main() {
    let character = CharacterBuilder::new().name("John").build1();
    println!("{character:?}");

    let character = CharacterBuilder::new()
        .name("John")
        .class(Class::Rogue)
        .build2();
    println!("{character:?}");

    let character = CharacterBuilder::new()
        .name("John")
        .age(42)
        .class(Class::Warrior)
        .health(67)
        .mana(420)
        .build2();
    println!("{character:?}");

    let character = CharacterBuilder::new().class(Class::Mage).build2();
    println!("{character:?}");
}
```