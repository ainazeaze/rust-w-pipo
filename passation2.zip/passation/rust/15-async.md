# Definition asynchrone

> https://fastapi.tiangolo.com/async/  
> https://doc.rust-lang.org/stable/book/ch17-00-async-await.html  

Le concept d'asynchrone décrit de la concurrence (ne pas confondre avec parallélisme).

Si on schématise un restaurant avec un serveur qui doit gérer des clients sans concurrence, on aurait quelque chose comme :
```rust
impl RestaurantServer {
	fn handle_clients(clients: Clients, chef: Chef) {
		self.welcome(clients);
		while !clients.have_order() {
			self.wait();
		}
		let order = clients.order();
		let cook = chef.cook(order);
		while !cook.is_finished() {
			self.wait();
		}
		let meal = cook.into_meal();
		self.serve(clients, meal);
		while clients.eating() {
			self.wait();
		}
		self.cash_in(clients);
		self.clean_table();
	}
}

fn main() {
	let server = RestaurantServer::new();
	let clients1 = Clients::new();
	let clients2 = Clients::new();
	server.handle_clients(clients1);
	server.handle_clients(clients2);
	println!("Closing Restaurant !");
}
```

Le problème dans ce cas est qu'on doit attendre que les `clients1` finissent de manger pour pouvoir gérer les `clients2`. On voit bien que ça n'est pas cohérent car le serveur attend a beaucoup de moment et il pourrait gérer les `clients2` pendant ces attentes. C'est ce que cherche a régler l'asynchrone avec la concurrence :
```rust
impl RestaurantServer {
	async fn handle_clients(clients: Clients, chef: Chef) {
		self.welcome(clients);
		let order = clients.order().await;
		let meal = chef.cook(order).await;
		self.serve(clients, meal);
		clients.eating().await;
		self.cash_in(clients);
		self.clean_table();
	}
}

async fn main() {
	let server = RestaurantServer::new();
	let clients1 = Clients::new();
	let clients2 = Clients::new();
	let handle1 = spawn_task(server.handle_clients(clients1));
	let handle2 = spawn_task(server.handle_clients(clients2));
	handle1.await;
	handle2.await;
	println!("Closing Restaurant !");
}
```

Il faut quand même mettre nos fonction asynchrones dans des tasks car si on fait un `await` sur les deux fonctions dans `main`, on aurait le même comportement qu'avant.
# Runtime et Futures

> https://rust-lang.github.io/async-book/part-guide/async-await.html  
> https://doc.rust-lang.org/stable/std/future/trait.Future.html  

Appeler une fonction `async` retourne une `Future` mais n'execute pas le code à l’intérieur. Pour que ça soit exécuté, il faut faire `.await` dessus. Pour faire un `.await` il faut être dans une fonction `async`.  `main` ne peut pas être `async`. Il nous faut donc un runtime : c'est la partie qui va gérer les différentes tasks en les stoppant/démarrant. Une `Future` a une méthode `poll` qui permet de dire a quel moment la donnée attendue est prête.

Rust ne donne pas de Runtime par défaut même si il donne une grande partie des élements async (`async`, `await`, `Future`). Pour faire simple, on va utiliser tokio :
```rust
async fn foo() -> i32 {
	println!("Returning 3");
    3
}

#[tokio::main]
async fn main() {
    // res: impl Future<Output = i32>
    let res = foo(); // foo is not called, no print
    
    let res: i32 = foo().await; // foo is called
    println!("{res}");
}
```

# Tasks

Pour faire fonctionner la concurrence, il faut utiliser des tasks :

```rust
use tokio::{spawn, time::{sleep, Duration}};

async fn say_hello() {
    // Wait for a while before printing to make it a more interesting race.
    sleep(Duration::from_millis(100)).await;
    println!("hello");
}

async fn say_world() {
    sleep(Duration::from_millis(100)).await;
    println!("world");
}

#[tokio::main]
async fn main() {
    let handle1 = spawn(say_hello());
    let handle2 = spawn(say_world());
    
    let _ = handle1.await;
    let _ = handle2.await;

    println!("!");
}
```

