# Description et objectifs du projet

Le projet vise a être un pont entre les autres micro-services et la cameras. Il communique avec les caméras (récupérer leurs images, changer leur configuration, ...) et expose des fonctionnalités.

Le projet panorama a un historique :
- [Camera Utils](https://gitlab.buawei.com/aqila/camera_utils) 
	- Projet avant mon arrivée
- Basler Flask puis [Camera Service](https://gitlab.buawei.com/pokaiok/basler_flask) (renommage)
	- Serveur FastAPI (python) qui utilise [pypylon](https://github.com/basler/pypylon/) pour les caméras basler et d'autres lib pour les autres constructeurs
- [Panorama](https://gitlab.buawei.com/pokaiok/panorama) (python)
	- Serveur FastAPI qui utilise [Aravis](https://github.com/AravisProject/aravis) pour la communication generique avec les caméras et [GStreamer](https://gstreamer.freedesktop.org/) pour la conversion des images
- [Panorama](https://gitlab.buawei.com/pokaiok/panorama-rs) (rust)
	- Réécriture de panorama en rust en réecrivant ce que faisait Aravis et GStreamer manuellement

# Utilisation de panorama (web)

> http://localhost:8092/docs  

# Standard GenICam

> https://gitlab.buawei.com/pokaiok/panorama-rs/-/wikis/GenICam  