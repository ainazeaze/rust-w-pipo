# Panorama (lib)

## API Camera

> [camera.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/camera.rs)

Le struct [CameraDetails](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/camera.rs#L107) définit les attributs définissant une caméra. C'est ce qui est 
Le trait [CameraTrait](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/camera.rs#L32) définit les méthodes que doivent avoir tout les types de caméra. L'enum [Camera](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/camera.rs#L25) définit tout les types de caméras.
Le trait [Access](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/camera.rs#L68) définit les méthodes de communication bas niveau avec les caméras.

## Recherche des cameras

La fonction [`search_all`](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/camera.rs#L265) va rechercher toutes les caméras en appelant respectivement [`UvInterface::search_all`](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/usb3vision/interface.rs#L36) pour les caméras USB et [`GvInterface::search_all`](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/gigevision/interface.rs#L119) pour les caméras ethernet.

La recherche des caméras ethernet se fait en envoyant une requête UDP broadcast qui est répondue par toutes les caméras qui la reçoivent avec des informations la concernant.

La recherche USB se fait en appelant `rusb` une librairie qui wrap `libusb`.

## Protocoles

> https://gitlab.buawei.com/pokaiok/panorama-rs/-/wikis/Protocoles  
> [gvcp.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/gigevision/gvcp.rs)  
> [gvsp.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/gigevision/gvsp.rs)  
> [uvcp.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/usb3vision/uvcp.rs)  
> [uvsp.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/usb3vision/uvsp.rs)  

## Document XML GenICam (GenApi)

> [genicam/mod.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/genicam/mod.rs)  

## Codec

> [media/mod.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/media/mod.rs)  

Utilisation des crates :
- [image](https://lib.rs/crates/image)
- [turbojpeg](https://lib.rs/crates/turbojpeg)
- [mp4](https://lib.rs/crates/mp4)
- [openh264](https://lib.rs/crates/openh264)
## Pipeline

> [stream.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/stream.rs)  

## Emulation

> [emulation/camera.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama/src/emulation/camera.rs)


# Panorama Web

## Serveur Web

> [main.rs](https://gitlab.buawei.com/pokaiok/panorama-rs/-/blob/a8aa87a5649f129c50c9a05ea4949f065c2e228c/crates/panorama-web/src/main.rs)  

## Endpoints


## Gestion des caméras




