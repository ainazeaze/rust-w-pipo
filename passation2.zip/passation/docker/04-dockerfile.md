# Dockerfile

Un Dockerfile est constitué d'instructions : https://docs.docker.com/reference/dockerfile

```dockerfile
FROM alpine

WORKDIR /app
COPY hello.txt .
RUN apk add python3

CMD ["python3", "-m", "http.server"]
```

# Build

Pour construire l'image on va utiliser la commande `docker image build` (ou juste `docker build`).

L'option `-t` permet de spécifier le nom de l'image et le tag. Le format est `nom:tag`. Si le `tag` n'est pas spécifié, le tag `latest` est utilisé.

```
$ docker build -t my-image:latest .
[+] Building 18.8s (10/10) FINISHED                                            docker:default
 => [internal] load build definition from Dockerfile
 => => transferring dockerfile: 191B
 => [internal] load metadata for docker.io/library/alpine:latest
 => [internal] load .dockerignore
 => => transferring context: 2B
 => [1/5] FROM docker.io/library/alpine:latest
 => [internal] load build context
 => => transferring context: 210B
 => CACHED [2/5] WORKDIR /app
 => [3/5] COPY main.py .
 => [4/5] RUN apk add python3 py3-pip
 => [5/5] RUN pip3 install --break-system-packages fastapi[standard]
 => exporting to image
 => => exporting layers
 => => writing image sha256:3b49d5f69feaddb72fc8a1ba439ff5740cb24d0cee9366b4828a2de5bc9
 => => naming to docker.io/library/my-image:latest
```

# Couche (Layers)

> https://docs.docker.com/get-started/docker-concepts/building-images/understanding-image-layers/  

Chaque ligne d'instruction dans le Dockerfile correspond à une couche. Chaque couche est dépendant ce sa couche parente (couche précédente).

Les layers d'une image peuvent se voir avec la commande `history` :
```
$ docker history my-image:latest
IMAGE          CREATED       CREATED BY                                SIZE
5f163ff1b8e3   4 days ago    CMD ["fastapi" "run"]                     0B
<missing>      4 days ago    RUN /bin/sh -c pip3 install --break-sys…  84MB
<missing>      4 days ago    RUN /bin/sh -c apk add python3 py3-pi…    64.7MB
<missing>      4 days ago    COPY main.py . # buildkit                 99B
<missing>      4 days ago    WORKDIR /app                              0B
<missing>      6 weeks ago   CMD ["/bin/sh"]                           0B
<missing>      6 weeks ago   ADD alpine-minirootfs-3.23.4-x86_64.ta…   8.45MB
```

On peut d'ailleurs remarquer que l'image est décrite uniquement sur le dernier layer, car une image est finalement qu'un pointeur vers un layer.

Et on peut également voir le contenu de chaque layer avec l'outil dive :
https://github.com/wagoodman/dive/

# Cache

Docker inclut un cache pour garder le résultat de layers si ils n'ont pas changés. Cela s'applique au moment de construire l'image (build) ou au moment de la récupérer (pull).

Par exemple, si on a les deux images suivantes :

```
FROM alpine
RUN echo hello
RUN apk add curl
CMD ["curl"]
```

```
FROM alpine
RUN echo hello
RUN apk add ping
CMD ["ping"]
```

En supposant que l'image `alpine` est identique dans les deux cas, ces deux images partagent (au moins) 2 layers commun : le `FROM` et le premier `RUN`.
Si la première a déjà été construite et est disponible sur le système, construire la deuxième va reprendre ces 2 layers dans le cache. De la même façon, si la première image existe sur le système, pull la deuxième ne va pas re-télécharger les 2 layers.

Étant donné que les layers dependent du layer precedent, cela veut dire que le changement d'un layer va invalider les layers suivants.

Avec l'exemple précédent, si on change la ligne 2 (`RUN echo hello`), les layers suivants devront se reconstruire.

# Registre

> https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-registry/  

Les images peuvent se stocker dans un registre. Il existe un registre par défaut dont on peut consulter à l'adresse https://hub.docker.com/.

Le registre ou va se trouver l'image est indiqué dans le nom de l'image. Par exemple, l'image `docker.io/library/alpine:latest` se trouve dans le registre officiel (`docker.io`) et dans le projet `library`. Si le registre n'est pas spécifié, c'est le registre officiel qui est utilisé.

Donc si on veut utiliser notre registre privé, il faudra nommer l'image `harbor.buawei.com/library/alpine:latest`.

# Règles des tags

> https://docs.docker.com/get-started/docker-concepts/building-images/build-tag-and-publish-an-image/#tagging-images  

Les tags sur les images dans les registres utilisent plusieurs règles et standards :
- Plusieurs tags peuvent pointer vers une même image
	- Dans https://hub.docker.com on voit souvent plusieurs lignes qui donne des tags et décrivent une même image avec des noms différents
	- Par exemple `python:3.14.5`, `python:3.14` et `python:3` pointent vers la même image à la date du 03/06/2026
- Les tags sont mutables, ils peuvent être écrasés pour pointer sur une nouvelle image
	- Par exemple le tag `python:3` bouge souvent pour pointer vers l'image de la dernière version python
	- Selon le registre, il est possible d'ajouter des règles pour éviter rendre un tag immutable
- On trouve souvent des variantes `alpine`, `slim`, ou des noms correspondants a des distributions ou a des OS
	- `alpine` sont des variantes utilisant la distribution `alpine` plus légère que les autres
	- `slim` sont des variantes souvent associés à des distributions debian qui proposent une alternative plus légère (avec des libraries système en moins)

