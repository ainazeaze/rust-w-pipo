> https://docs.docker.com/build/building/best-practices/  

# Optimiser le cache

> https://docs.docker.com/build/cache/optimize/  
> https://docs.docker.com/build/building/best-practices/#leverage-build-cache  

Étant donné que les layers sont dépendants du layer précédent, il est important d'organiser les layers pour profiter au maximum du cache.

Par exemple dans l'exemple précedent :
```dockerfile
FROM alpine

WORKDIR /app
COPY hello.txt .
RUN apk add python3

CMD ["python3", "-m", "http.server"]
```

Si le fichier `hello.txt` change, la commande `apk add` sera invalidé même si il n'a pas changé. Pourtant ces layers sont indépendants : le fichier ne change pas le comportement de la commande.

Il est donc possible d'optimiser cette image simplement en inversant les deux layers :
```dockerfile
FROM alpine

WORKDIR /app
RUN apk add python3
COPY hello.txt .

CMD ["python3", "-m", "http.server"]
```

Ainsi, changer le fichier `hello.txt` n'invalide pas le cache l'installation de python.

La bonne pratique est de mettre les elements qui changent le moins le plus tôt possible, tandis que les elements qui changent souvent (comme le code source) doivent être mis le plus tard possible.

# Réduire la taille des images

> https://docs.docker.com/build/building/best-practices/#sort-multi-line-arguments  

Avec ou sans cache, une image peut être très lourde. Il existe plusieurs manière de réduire la taille d'une image, qui mènent tous vers le même résultat : ne pas ajouter des fichiers non utilisés dans l'image.

Étant donné le fonctionnement des layers, supprimer un fichier après sa création ne réduit pas la taille de l'image.

Par exemple, ce Dockerfile génère une image qui garde la taille du fichier créé bien qu'il n'existe plus lorsqu'on lance le container :
```dockerfile
FROM alpine

WORKDIR /app
RUN dd if=/dev/urandom of=large.bin bs=64M count=1 iflag=fullblock
RUN rm large.bin
```

Dans un exemple plus concret, on est souvent amené à utiliser `apt` dans les `Dockerfile` qui créé du cache dans le système par défaut. On souhaite ne pas avoir ce cache pour gagner de l'espace. Le `Dockerfile` non optimisé ressemble à :
```dockerfile
FROM debian

RUN apt update
RUN apt install -y curl
RUN rm -rf /var/lib/apt/lists/*
```

Dans ce cas, ça n'est pas utile car on supprime le cache dans un layer alors qu'il existe dans un layer précédent. Pour que ça soit vraiment pris en compte, il faut empêcher sa création dans un layer. Cela peut se faire en enchaînant les commande dans un seul layer :
```dockerfile
FROM debian

RUN apt update && \
  apt install -y curl && \
  rm -rf /var/lib/apt/lists/*
```

# Multi-stage build

> https://docs.docker.com/get-started/docker-concepts/building-images/multi-stage-builds/  

Imaginons un cas ou on a une application qui se compile :

```c
#include <stdio.h>
int main() {
  printf("Hello World!\n");
}
```

On aurait le Dockerfile suivant :

```dockerfile
FROM alpine

WORKDIR /app
RUN apk add gcc libc-dev
COPY main.c .
RUN gcc -o main main.c

CMD [ "./main" ]
```

On doit installer un compilateur pour créer l'executable mais cela ne nous sert plus une fois que l'executable est créée.

Pour ce faire, on peut utiliser le multi-stage build qui permet de faire une image temporaire qu'on utilisera seulement pour compiler et l'image finale récupère l'executable :
```dockerfile
FROM alpine AS builder

WORKDIR /app
RUN apk add gcc libc-dev
COPY main.c .
RUN gcc -o main main.c

FROM alpine

WORKDIR /app
COPY --from=builder /app/main .

CMD [ "./main" ]
```

Dans ce cas, la taille de l'image passe de 210MB à 9MB.

# Nettoyer facilement les elements non utilisés

```
$ docker system df
TYPE            TOTAL     ACTIVE    SIZE      RECLAIMABLE
Images          74        5         10.08GB   8.448GB (83%)
Containers      5         0         20.36kB   20.36kB (100%)
Local Volumes   112       0         1.186GB   1.186GB (100%)
Build Cache     825       0         47.28GB   45.94GB
```

Pour nettoyer les elements non utilisés :
- `docker system prune` pour nettoyer tout les types d'elements
- `docker image prune` pour nettoyer seulement les images
- `docker container prune` pour nettoyer seulement les containers
- `docker volume prune` pour nettoyer seulement les volumes
- `docker network prune` pour nettoyer seulement les réseaux

# Fixer la version sur une image

Spécifier le tag le plus précis sur une image est une bonne étape mais on peut aller plus loin.

Il est possible dans le Dockerfile de specifier un digest pour pinner l'image : https://docs.docker.com/build/building/best-practices/#pin-base-image-versions

Par exemple, le digest de l'image `ubuntu:24.04` le 03/06/2026 est `sha256:786a8b558f7be160c6c8c4a54f9a57274f3b4fb1491cf65146521ae77ff1dc54`, on peut donc écrire le `Dockerfile` :
```
FROM ubuntu:24.04@sha256:786a8b558f7be160c6c8c4a54f9a57274f3b4fb1491cf65146521ae77ff1dc54
```

Le digest se trouve quand on fait un `docker pull` :
```
$ docker pull ubuntu:24.04
24.04: Pulling from library/ubuntu
Digest: sha256:786a8b558f7be160c6c8c4a54f9a57274f3b4fb1491cf65146521ae77ff1dc54
Status: Image is up to date for ubuntu:24.04
docker.io/library/ubuntu:24.04
```

Ou quand on fait un `docker inspect` :
```
$ docker inspect ubuntu:24.04
[
    {
        "Architecture": "amd64",
        "Config": {
            "Cmd": [
                "/bin/bash"
            ],
            "Env": [
                "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
            ],
            "Labels": {
                "org.opencontainers.image.version": "24.04"
            }
        },
        "Created": "2026-05-20T01:37:22.119122873Z",
        "DockerVersion": "26.1.3",
        "GraphDriver": {
            "Data": {
                "MergedDir": "/var/lib/docker/overlay2/75225377dc293bbbb5b0eb6f34a088ea5b6415d1496c5e7201030d91de6951fd/merged",
                "UpperDir": "/var/lib/docker/overlay2/75225377dc293bbbb5b0eb6f34a088ea5b6415d1496c5e7201030d91de6951fd/diff",
                "WorkDir": "/var/lib/docker/overlay2/75225377dc293bbbb5b0eb6f34a088ea5b6415d1496c5e7201030d91de6951fd/work"
            },
            "Name": "overlay2"
        },
        "Id": "sha256:8bf6fbc94074daccf0d7e43395600ddd71aa5a9e486cf0d1a19cc36583f8401e",
        "Metadata": {
            "LastTagTime": "0001-01-01T00:00:00Z"
        },
        "Os": "linux",
        "RepoDigests": [
            "ubuntu@sha256:786a8b558f7be160c6c8c4a54f9a57274f3b4fb1491cf65146521ae77ff1dc54"
        ],
        "RepoTags": [
            "ubuntu:24.04"
        ],
        "RootFS": {
            "Layers": [
                "sha256:98effb2dfe85d4c431f97d90482075f19e5fc3a57c2dd423d8bdfd4813620043"
            ],
            "Type": "layers"
        },
        "Size": 78141343
    }
]
```

# Utiliser un utilisateur non-root

> https://www.docker.com/blog/understanding-the-docker-user-instruction/

```
FROM alpine

WORKDIR /app
RUN apk add python3
COPY hello.txt .
ENV HELLO="hello"

RUN adduser -D my-user
USER my-user

CMD ["python3", "-m", "http.server"]
```