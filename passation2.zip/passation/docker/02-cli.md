# `help`

La commande `docker help` (ou juste `docker`) sert à avoir des infos sur la CLI docker.

Il y a beaucoup de commandes, deux sont plus importantes que les autres :
- `docker container` sert à manipuler les containers
- `docker image` sert à manipuler les images

Étant donné que beaucoup de sous-commandes de ces deux commandes sont fréquentes, on trouve des alias qui permettent de faire la commande plus facilement. Par exemple, `docker image pull` peut se raccourcir en `docker pull`.

# `image pull` ou `pull`

```
$ docker pull nginx:alpine
alpine: Pulling from library/nginx
6a0ac1617861: Already exists
d591de949fc4: Pull complete
43e17fbea4a6: Pull complete
390b5c71f63d: Pull complete
4db114418873: Pull complete
36afaf697832: Pull complete
9b1872bceaab: Pull complete
b009abd4e3ad: Pull complete
Digest: sha256:5f979dcfed4ce6461873f087e8c980d6e29b084b9e8776d9704a7e989b5f4898
Status: Downloaded newer image for nginx:alpine
docker.io/library/nginx:alpine
```

# `container create` ou `create`

```
$ docker create nginx:alpine
2db2f3a8379b45889a7860c95a555262ee8fc68aefa83ad9191dd0b9892e4678
```

# `container start` ou `start`

```
$ docker start 2db
2db
```

# `container run` ou `run`

```
$ docker run -d alpine
759fe016a97d3d178b8bbd0023e4af6de96ae174bef62807e39e591673dee852
```

# `container ls` ou `ps`

```
$ docker ps
CONTAINER ID   IMAGE          COMMAND                  CREATED          STATUS          PORTS     NAMES
2db2f3a8379b   nginx:alpine   "/docker-entrypoint.…"   13 seconds ago   Up 12 seconds   80/tcp    confident_rhodes

$ docker ps -a
CONTAINER ID   IMAGE          COMMAND                  CREATED          STATUS                     PORTS     NAMES
759fe016a97d   alpine         "/bin/sh"                4 seconds ago    Exited (0) 3 seconds ago             gallant_vaughan
2db2f3a8379b   nginx:alpine   "/docker-entrypoint.…"   15 seconds ago   Up 14 seconds              80/tcp    confident_rhodes
```

# `container logs` ou `logs`

```
$ docker logs 2d
/docker-entrypoint.sh: /docker-entrypoint.d/ is not empty, will attempt to perform configuration
/docker-entrypoint.sh: Looking for shell scripts in /docker-entrypoint.d/
/docker-entrypoint.sh: Launching /docker-entrypoint.d/10-listen-on-ipv6-by-default.sh
10-listen-on-ipv6-by-default.sh: info: Getting the checksum of /etc/nginx/conf.d/default.conf
10-listen-on-ipv6-by-default.sh: info: Enabled listen on IPv6 in /etc/nginx/conf.d/default.conf
/docker-entrypoint.sh: Sourcing /docker-entrypoint.d/15-local-resolvers.envsh
/docker-entrypoint.sh: Launching /docker-entrypoint.d/20-envsubst-on-templates.sh
/docker-entrypoint.sh: Launching /docker-entrypoint.d/30-tune-worker-processes.sh
/docker-entrypoint.sh: Configuration complete; ready for start up
```

# `container inspect` ou `inspect`

```
$ docker inspect 2d
[
    {
        "Id": "2db2f3a8379b45889a7860c95a555262ee8fc68aefa83ad9191dd0b9892e4678",
        "Created": "2026-05-28T14:49:44.425361066Z",
        "Path": "/docker-entrypoint.sh",
        "Args": [
            "nginx",
            "-g",
            "daemon off;"
        ],
        "State": {
            "Status": "running",
            "Running": true,
            "Paused": false,
            "Restarting": false,
            "OOMKilled": false,
            "Dead": false,
            "Pid": 89210,
            "ExitCode": 0,
            "Error": "",
            "StartedAt": "2026-05-28T14:49:44.519357882Z",
            "FinishedAt": "0001-01-01T00:00:00Z"
        },
...
```

# `image ls` ou `images`

```
$ docker images
IMAGE                                         ID             DISK USAGE
alpine:latest                                 3cb067eab609       8.45MB
nginx:alpine                                  da954fb959a3       62.3MB
```

# `image inspect` ou `inspect`

```
$ docker inspect nginx:alpine
[
    {
        "Id": "sha256:da954fb959a34e2195e6bf622e6396bf338f99e0fe6d8e641b302d9aaa1f0645",
        "RepoTags": [
            "nginx:alpine"
        ],
        "RepoDigests": [
            "nginx@sha256:8b1e78743a03dbb2c95171cc58639fef29abc8816598e27fb910ed2e621e589a"
        ],
        "Comment": "buildkit.dockerfile.v0",
        "Created": "2026-05-22T18:30:44.353373585Z",
        "Config": {
            "ExposedPorts": {
                "80/tcp": {}
            },
            "Env": [
	            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "NGINX_VERSION=1.31.1",
                "PKG_RELEASE=1",
                "DYNPKG_RELEASE=1",
                "NJS_VERSION=0.9.9",
                "NJS_RELEASE=1",
                "ACME_VERSION=0.4.1"
            ],
...
```

# `container top` ou `top`

```
$ docker top 2db
UID                 PID                 PPID                C                   STIME               TTY                 TIME                CMD
root                27116               27092               0                   09:48               ?                   00:00:00            nginx: master process nginx -g daemon off;
systemd+            27219               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27220               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27221               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27222               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27223               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27224               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27225               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27226               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27227               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27228               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27229               27116               0                   09:48               ?                   00:00:00            nginx: worker process
systemd+            27230               27116               0                   09:48               ?                   00:00:00            nginx: worker process
```

# `container stats` ou `stats`

```
$ docker stats 2db
CONTAINER ID   NAME            CPU %     MEM USAGE / LIMIT     MEM %     NET I/O         BLOCK I/O         PIDS
2db2f3a8379b   awesome_hertz   0.00%     17.45MiB / 38.86GiB   0.04%     8.37kB / 126B   24.7MB / 20.5kB   13
```

# `container cp` ou `cp`

```
$ docker cp hello.txt 2db:/hello.txt
Successfully copied 13B (transferred 2.05kB) to 2db:/hello.txt

$ docker cp 2db:/hello.txt hello.txt
Successfully copied 13B (transferred 2.05kB) to ./hello.txt
```

# `container stop` ou `stop`

```
$ docker stop 2db
2db
```

# `container rm` ou `rm`

Le container doit être stoppé pour pouvoir être supprimé

```
$ docker rm 2db
2db
```

# `image rm` ou `rmi`

Il ne doit y avoir aucun container qui tourne avec l'image pour pouvoir la supprimer 
```
$ docker rmi nginx:alpine
Untagged: nginx:alpine
Untagged: nginx@sha256:8b1e78743a03dbb2c95171cc58639fef29abc8816598e27fb910ed2e621e589a
Deleted: sha256:da954fb959a34e2195e6bf622e6396bf338f99e0fe6d8e641b302d9aaa1f0645
Deleted: sha256:602e6920d896668a78e824cda9014d172fe65d9e8602801780a904e1a54599e5
Deleted: sha256:7857cd2faa152ba9821a214cfae05c670138b8a3639a21c18ef9fd948d806df1
Deleted: sha256:056a1c50a63d79662735c2df6d88d3184077b66ec2c35699f33c4e84db47cbd2
Deleted: sha256:38a6bea0044065fdeeb7b76d17d820fd325fa1ff04cada22549f1cba753f9dd5
Deleted: sha256:e22662bf47a325dce3997d557e38ade4f2625af398d8ddda9922d1490fd56288
Deleted: sha256:b0ab97d9464c6e92e4a40f8675bcb10849d4da9a7e734e00524765689a8ffaf0
Deleted: sha256:427cce048b80430e61c76d902c604d4a7ca136d79605f772518c09c04c00b37b
```