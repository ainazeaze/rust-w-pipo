# Help

```
$ docker run --help
```

# Interactif et détaché

- `-i` (ou `--interactive`) : garde stdin ouvert pour le processus du container (permet d’envoyer des entrées).
- `-t` (ou `--tty`) : alloue un pseudo‑TTY qui fait croire au processus qu’il est connecté à un vrai terminal.
- `-d` (ou `--detach`) : démarre le container en tâche de fond.

# Auto-suppression

L'option `--rm` permet de supprimer automatiquement le container lors qu'il a terminé

# Nommage

L'option `--name` permet de nommer le container

# Environnements

L'option `-e` (ou `--env`) permet de passer des environnements un container. C'est le moyen le plus simple de passer des informations dans un container et de condition l'execution d'un programme.

```
$ docker run -it --rm -e HELLO="Hello" -e WORLD="World !" alpine
/ # echo $HELLO $WORLD
Hello World !
```

# Stockage et volumes

L'option `-v` (ou `--volume`) permet de partager un dossier ou fichier entre l'hôte et le container. C'est le moyen le plus simple de persister et partager des fichiers. La syntaxe attendue est `SOURCE_HOST:DESTINATION_CONTAINER`.

Il existe deux façons d'invoquer cette commande :

En utilisant un chemin (absolu ou relatif) en tant que source, on utilise le mode "binding"
```
$ mkdir work

$ echo "hello from host" > work/hello.txt

$ docker run -it --rm -v $PWD/work:/host-work alpine
/ # ls /host-work/
hello.txt
/ # cat /host-work/hello.txt
hello from host
/ # echo "hello back from $HOSTNAME" >> /host-work/hello.txt

$ cat work/hello.txt
hello from host
hello back from e3f27775902a
```

En utilisant un nom simple (sans `/`) en tant que source, on utilise le mode "volume"
```
$ docker run -it --rm -v work:/host-work alpine
/ # echo "hello from inside" > /host-work/hello.txt

$ docker run -it --rm -v work:/host-work alpine
/ # cat /host-work/hello.txt
hello from inside
```

Si le volume n'existe pas, il sera créé. Docker gère lui-même ses volumes, on peut les voir avec la commande :
```
$ docker volume ls
local     work
```

Et les inspecter avec la commande :
```
$ docker volume inspect work
[
    {
        "CreatedAt": "2026-05-29T11:52:18+02:00",
        "Driver": "local",
        "Labels": null,
        "Mountpoint": "/var/lib/docker/volumes/work/_data",
        "Name": "work",
        "Options": null,
        "Scope": "local"
    }
]
```

Si on veut, on peut aller regarder directement ce qu'il y a dans le volume mais on a besoin des droits root :
```
$ sudo cat /var/lib/docker/volumes/work/_data/hello.txt
hello from inside
```

Si on veut en créer un manuellement sans avoir à démarrer un container, on peut utiliser `docker volume create`, et les supprimer avec `docker volume rm`

# Réseau

Le container est isolé dans un réseau ce qui le rend inaccessible par défaut.

```
$ docker run -it --rm nginx:alpine
```

Sur un autre terminal :
```
$ curl -v 127.0.0.1:80
*   Trying 127.0.0.1:80...
* connect to 127.0.0.1 port 80 from 127.0.0.1 port 50938 failed: Connection refused
* Failed to connect to 127.0.0.1 port 80 after 0 ms: Couldn't connect to server
* Closing connection
```

Il y a plusieurs moyen de permettre de communiquer avec un container par le réseau.

Le moyen le plus simple est de désactiver l'isolation réseau avec `--network host` :
```
$ docker run -it --rm --network host nginx:alpine
```

Sur un autre terminal :
```
$ curl 127.0.0.1:80
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title
```

Mais on peut faire mieux, comme par exemple en faisant un binding de port pour exposer que ce dont on a besoin avec l'option `-p` (ou `--publish`). Comme pour les volumes, la syntaxe attendue est `HOST_PORT:CONTAINER_PORT`. Le port côté doit être libre et peut être different du port utilisé dans le container. Ainsi, il est possible d'avoir plusieurs containers qui livrent un service qui écoutent sur le même port sans se marcher dessus.

Par exemple :
```
$ docker run -it --rm -p 8080:80 nginx:alpine
```

Sur un autre terminal :
```
$ curl 127.0.0.1:8080
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title
```

On peut également partager un réseau entre différents containers pour qu'ils puissent communiquer ensemble avec l'option `--network`. Il suffit de créer un réseau :
```
$ docker network create my-network
6b283d098e6ca98fdf74a24dbc9fc69975b0d9e08c5646f08899b188595ce556
```

Puis de créer les containers avec ce réseau en utilisant le nom du container comme adresse lors qu'on souhaitera envoyer une requête :
```
$ docker run -d --rm --name my-nginx --network my-network nginx:alpine
$ docker run -it --rm --network my-network alpine
/ # apk add curl
/ # curl my-nginx
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
```

# Limitation CPU

Plusieurs façons de limiter la charge CPU sur un container. La façon la plus simple est d'utiliser l'option `--cpus`.

Lancer `htop` sur un autre terminal sur le host pour vérifier la consommation CPU du système dans chaque cas.

```
$ docker run -it --rm alpine
/ # apk add stress-ng
/ # stress-ng --cpus 12

$ docker run -it --rm --cpus 2 alpine
/ # apk add stress-ng
/ # stress-ng --cpus 12
```

# Limitation mémoire

L'option `-m` (ou `--memory`) permet de limiter la charge mémoire sur un container.

Lancer `docker stats` sur un autre terminal pour voir la consommation mémoire du container. Par exemple, un cas extrême et facile a produire :

```
$ docker run -it --rm -m 10MB alpine
/ # apk add python3
Killed
```