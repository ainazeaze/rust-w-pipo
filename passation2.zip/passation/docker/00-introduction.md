# Définition de la conteneurisation

> https://www.docker.com/resources/what-container/  

La conteneurisation est une méthode d’isolation légère qui encapsule une application et ses dépendances dans un environnement exécutable standardisé (un conteneur).

Contrairement aux machines virtuelles, les conteneurs partagent le noyau de l’OS hôte tout en gardant une séparation des processus, du système de fichiers et des réseaux, ce qui facilite la portabilité et la cohérence entre environnements.

L'objectif est d'avoir une application qui tourne peu importe la machine.

# Image et container

> https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-an-image/  
> https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-container/  

Une image est un artefact immuable, couche de fichiers en lecture seule qui contient tout le nécessaire pour exécuter une application (OS minimal, bibliothèques, binaires, configuration). On la construit avec un Dockerfile et on la stocke dans un registre.

Un container est une instance en cours d’exécution d’une image. Le container ajoute une couche en lecture-écriture, des namespaces et des cgroups pour isolation et ressources.

# Avantage et limites

- Avantages : démarrage rapide, densité élevée, portabilité entre environnements, reproductibilité, faciliter le déploiement continu et la micro‑architecture.
- Limites : isolation moins forte que VM (même noyau), gestion de la persistance des données et des volumes, complexité réseau et orchestration à grande échelle, besoins en sécurité (vulnérabilités d’images, configuration des privilèges).

# Fonctionnement bas niveau

> https://alpinelinux.org/downloads/  
> https://wiki.alpinelinux.org/wiki/Alpine_Linux_in_a_chroot  

```
$ chroot .        
chroot: cannot change root directory to '.': Operation not permitted

$ sudo chroot .
chroot: failed to run command ‘/bin/bash’: No such file or directory

$ sudo chroot . sh

# echo -e 'nameserver 8.8.8.8' > /etc/resolv.conf

# curl
sh: curl: not found

# apk add curl

# curl
curl: try 'curl --help' or 'curl --manual' for more information

# apk add python3

# python3 -m http.server
```

https://github.com/codecrafters-io/build-your-own-x#build-your-own-docker

# Histoire de la conteneurisation

- chroot (Unix - 1979)
- jail (FreeBSD - 2000)
- Linux Containers (LXC) (2008)
- docker (2013)
- Open Container Initiative (OCI) (2015)

# Composantes de docker

Docker Daemon (`dockerd`) : service de fond qui gère images, containers, réseaux et volumes, expose une API REST pour les clients.

[Moby](github.com/moby/moby): projet upstream (boîte à outils) dont plusieurs composants servent à construire Docker Engine.

[`containerd`](https://github.com/containerd/containerd) : composant bas‑niveau géré par le daemon pour la gestion du cycle de vie des containers (téléchargement d’images, stockage, exécution).
Étant donnée que docker utilise `containerd`, on peut techniquement l'utiliser pour accéder à nos ressources :
```
$ sudo ctr -n moby containers list
CONTAINER                                                           IMAGE    RUNTIME
3ad223a4195b6245d8d8b8386a56abe200360858e518548d4eb72219947b4177    -        io.containerd.runc.v2
c1aa01527228359736d786881920dbc7dd16b10a9906fc4972779116f5c5a6bb    -        io.containerd.runc.v2

$ docker ps
CONTAINER ID   IMAGE                                                   COMMAND                  CREATED        STATUS       PORTS     NAMES
3ad223a4195b   harbor.buawei.com/pokaiok/opcua:1.3.7                   "docker-entrypoint.s…"   3 months ago   Up 7 hours             opcua
c1aa01527228   harbor.buawei.com/pokaiok/ftp:1.0.0                     "/usr/local/bin/init…"   3 months ago   Up 7 hours             ftp
```

[`runc`](https://github.com/opencontainers/runc) : utilitaires qui créent et isolent le processus du container via les primitives du noyau (namespaces, cgroups).  

Le flux typique : le client Docker envoie des commandes au daemo, dockerd utilise containerd et containerd invoque runc pour lancer le processus isolé du container.

