# docker-compose

> https://docs.docker.com/compose/  

Docker-compose sert a structurer la façon dont les containers seront lancés.

```Dockerfile
# my-python/Dockerfile
FROM python:3.14-alpine

WORKDIR /app
RUN pip3 install --break-system-packages fastapi[standard]
COPY main.py .

CMD ["fastapi", "run"]
```

```python
import os
from fastapi import FastAPI, Request

app = FastAPI()

@app.get("/")
def root():
    return "Hello World!"


@app.get("/ip")
def get_ip(req: Request):
    return req.client


@app.get("/envs")
def envs():
    return os.environ
```

```Dockerfile
# my-nginx/Dockerfile
FROM nginx

COPY default.conf /etc/nginx/conf.d/default.conf
```

```nginx
# my-nginx/default.conf
server {
    listen       80;
    server_name  localhost;

    location / {
        proxy_pass http://my-python:8000/;
    }
}
```

```yaml
# docker-compose.yaml
services:
  my-python:
    build: my-python
    environment:
      - HELLO=hello
      - WORLD=world

  my-nginx:
    build: my-nginx
    ports:
      - 80:80
```

Cette structure permet de lancer une application python avec un nginx en tant que proxy. Le nginx est accessible de l’extérieur par un binding de ports.
Docker-compose va se charger automatiquement de créer un réseau ou il va mettre tout les containers décrits.

# Kubernetes (k8s)

> https://kubernetes.io/  

# PokaiokCTL

> https://gitlab.buawei.com/pokaiok/devops/pokaiokctl  

Configuration des containers par les labels avec une notion plus "user-friendly" envers les personnes qui n'ont pas de notion à Docker.

```dockerfile
LABEL pctl.env.RUST_LOG='{"choices": ["TRACE", "DEBUG", "INFO", "WARN"], "default": "INFO"}'
LABEL pctl.env.RING_SIZE='{"type": "int", "default": 40, "info": "Ring size to use. Larger values will increase number of frames stored."}'
LABEL pctl.env.BAYER_ALGORITHM='{"choices": ["NearestNeighbor", "Bilinear"], "default": "Bilinear"}'
LABEL pctl.volume.1='{"src": "/srv/exchange", "dest": "/pokaiok/exchange"}'
LABEL pctl.volume.2='{"src": "/var/log/pokaiok", "dest": "/pokaiok/logs"}'
```