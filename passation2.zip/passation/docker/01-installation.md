# Docker

> https://get.docker.com/  

1. download the script
	`$ curl -fsSL https://get.docker.com -o install-docker.sh`
2. verify the script's content
	`$ cat install-docker.sh`
3. run the script with --dry-run to verify the steps it executes
	`$ sh install-docker.sh --dry-run`
4. run the script either as root, or using sudo to perform the installation.
	`$ sudo sh install-docker.sh`

# Post install

Pour pouvoir lancer les commandes docker sans droits root, il est possible de s'ajouter dans le groupe `docker` :
```
$ sudo usermod -aG docker $USER
```

# Configuration du daemon docker

On peut configurer le daemon docker grace au fichier `/etc/docker/daemon.json`. Par exemple ce qui est utilisé sur les valises :
```json
{
    "runtimes": {
        "nvidia": {
            "path": "nvidia-container-runtime",
            "runtimeArgs": []
        }
    },
    "exec-opts": ["native.cgroupdriver=cgroupfs"], 
    "log-driver": "json-file",
    "log-opts": {
        "max-size": "20m",
        "max-file": "5"
    }
}
```