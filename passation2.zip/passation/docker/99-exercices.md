# Micro-services

```python
from fastapi import FastAPI, Request

app = FastAPI()


@app.get("/")
def root():
    return "Hello World!"


@app.get("/ip")
def get_ip(req: Request):
    return req.client
```

Avec le code ci-dessus :
1. L’exécuter dans un container avec une image `alpine` dans un `docker run` et faire une requête depuis l’extérieur
	- Il faudra installer les packages `python3` et `py3-pip`
	- Pour installer FastAPI dans un container, le plus simple est d’exécuter `pip3 install --break-system-packages fastapi[standard]`
	- Lancer le serveur avec `fastapi run`
2. L'exécuter dans un container avec une image `python` dans un `docker run` et faire une requête depuis l'extérieur
3. Ajouter un container `nginx` en tant que reverse proxy. Le serveur python doit être inaccessible directement.

```nginx
# /etc/nginx/conf.d/default.conf
server {
    listen       80;
    server_name  localhost;

    location / {
        proxy_pass http://${SERVER_URL}:8000/; # 'SERVER_URL' doit être le nom du container
    }
}
```

4. Refaire les questions précédentes en écrivant des `Dockerfile`
	- Pour avoir le `SERVER_URL` après le build, il faudra surement utiliser une variable d'environnement ainsi que les templates de configuration nginx : https://hub.docker.com/_/nginx#using-environment-variables-in-nginx-configuration-new-in-119

