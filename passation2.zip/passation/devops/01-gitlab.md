# Mise à jour

> https://docs.gitlab.com/releases/  
> https://endoflife.date/gitlab  

Vérifier si il y a besoin de mettre à jour Gitlab via la page admin : https://gitlab.buawei.com/admin

Connexion au Gitlab via le serveur infra

```sh
$ sudo su

# cd /srv
# bash schedule-update.sh
```