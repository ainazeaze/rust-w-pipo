# Fonctionnement

Connexion sur le serveur Integration via le bastion infra.

Les runners ont des releases en même temps que le serveur Gitlab et portent la même version. Il n'est pas nécessaire que le runner soit à la même version que Gitlab.

# Configuration

Pour modifier la configuration des runners sur le serveur d'integration :
```
$ docker run --rm -it -v gitlab-runner-config:/etc/gitlab-runner busybox

# vi /etc/gitlab-runner/config.toml

$ docker restart gitlab-runner
```