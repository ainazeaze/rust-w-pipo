# Mise à jour des images de base

> https://app.clickup.com/t/86c8yzzu7  

