> [Ticket Extraire les versions et licenses des dépendances (Panorama)](https://app.clickup.com/t/86c6vyf24)  
> [Ticket Automatiser le listing de dépendance + vulnérabilité](https://app.clickup.com/t/86c7we9vk)  

