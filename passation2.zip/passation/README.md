# Formations Passation

## Docker

La formation Docker a pour but d'être un requis à la passation PokaiokCTL et DevOps, ainsi que de remettre tout le monde a niveau. 

- Caractéristiques et concept de la conteneurisation
	- Définition de la conteneurisation
	- Image et container
	- Avantage et limites
	- Fonctionnement bas niveau
	- Histoire de la conteneurisation
	- Composantes de docker
- Installation et configuration Docker
- Utilisation de la CLI Docker
- Options des containers
	- Environnements
	- Stockage et volumes
	- Réseau
- Création d'une image docker
	- Dockerfile
	- Cache
	- Couches (Layers)
	- Registre
- Bonnes pratiques
	- Optimiser le cache
	- Réduire la taille des images
	- Multi-stage build
	- Nettoyer facilement les elements non utilisés
	- Fixer la version sur une image
	- Utiliser un utilisateur non-root
- Orchestration
	- docker-compose
	- Kubernetes (k8s)
	- PokaiokCTL (le meilleur des 3)

## Rust

La formation Rust a pour but d'être un requis à la passation Panorama

- Introduction
	- Caractéristiques et concept du langage
	- Forces et limites
- Outils
- Bases
- Mémoire
- Ownership et Borrowing
- Struct, Enums et Methodes
- Traits
- Généricité
- Iterator
- Lifetime
- Smart Pointers
- Concurrence (Thread)
- Patterns
- Modules
- Tests unitaires
- Ecosystème
- Async

## Panorama

- Description et objectifs du projet
- Utilisation de panorama
- Standard GenICam
- Explication des modules
	- Panorama (lib)
		- API Camera
		- Recherche des caméras
		- Protocole GVCP
		- Protocole GVSP
		- Protocole UVCP
		- Protocole UVSP
		- Document XML GenICam (GenApi)
		- Encodage et le décodage des formats média JPEG, MP4, Bayer, RGB
		- Pipeline des images depuis leur réception jusqu'à leur disponibilité
		- Emulation
	- Panorama Web
		- Serveur Web
		- Description des endpoints permettant d'agir sur les caméras
		- Interface OpenAPI (avec Scalar) pour voir tous les endpoints de l'API
		- Gestion des caméras dans une collection avec vérification de clé dans la caméra
		- Couche qui définit certains comportements produits (la définition automatique de certains paramètres caméras, la recherche d'alias pour les features, ...)
- Modules annexes (panorama-egui et fake-camera)
- Lentille Liquide
- Possibles améliorations et tickets en cours

## PokaiokCTL

- Explication des modules
	- PokaiokCTL (lib)
		- Gestion de produit et des services
		- Écriture et lecture des configurations
		- Utilisation des labels
		- Mise à jour des outils annexes (pipx)
		- Communication avec le registre docker
		- Actions sur la BDD (automatique et manuel)
		- Nettoyage des images docker (automatique et manuel)
		- Mise à jour offline avec le package Buawei
	- PokaiokCTL Web
		- Description des endpoints qui utilisent les fonctions de la lib
		- Connexion Websocket avec le front
		- Écriture et lecture des configurations
		- Process de mise à jour
	- PokaiokCTL CLI
		- Architecture CLI
		- Écriture et lecture des configurations
		- Process de mise à jour
		- Process de self-update
- mise à jour pokaiok-db (mise à jour des données)


## DevOPS

- Gitlab
	- Maintenance du serveur
		- Mise à jour régulière
		- Bannir les gens qui partent et ceux qui sont pas sages
- Gitlab CI/CD
	- Maintenance Runner
		- Fonctionnement des runners
		- Description des runners
		- Configuration des runners
		- Activité dans le serveur d'integration
		- Mise à jour des runners
	- Écriture et maintenance des fichiers `.gitlab-ci.yml`:
		- Tests unitaires
		- Build et déploiement dans les registres (PyPI, Harbor, Gitlab)
- Dockerfile
	- Maintenance des images
		- Mise à jour des images de bases
		- Optimisation
- Cyber
	- Génération d'un fichier comprenant les licenses et les versions des dépendances utilisées
	- Analyse des vulnérabilités
